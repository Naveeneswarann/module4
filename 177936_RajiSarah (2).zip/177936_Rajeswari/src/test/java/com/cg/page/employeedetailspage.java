package com.cg.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class employeedetailspage {
WebDriver webDriver;
	
	private WebElement titlename;
	
	@FindBy(how=How.XPATH, using="/html/body/h4" )
	@CacheLookup
	private WebElement textnamee;
	
	@FindBy(how = How.NAME, using = "graduation")
	@CacheLookup
	private WebElement graduation;

	@FindBy(how = How.ID, using = "txtPercentage")
	@CacheLookup
	private WebElement percentage;

	@FindBy(how = How.NAME, using = "passingYear")
	@CacheLookup
	private WebElement passingYear;

	@FindBy(how = How.ID, using = "txtProjectName")
	@CacheLookup
	private WebElement projectName;

	@FindBy(how = How.ID, using = "cbTechnologies")
	@CacheLookup
	private WebElement technologiesused;
	
	@FindBy(how = How.ID, using = "txtOtherTechs")
	@CacheLookup
	private WebElement othertechnologies;

	@FindBy(how = How.ID, using = "btnRegister")
	@CacheLookup
	private WebElement registerbtn;
	

public WebElement getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}
	public WebElement getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}
	public WebElement getPassingYear() {
		return passingYear;
	}
	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}
	public WebElement getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}
	public WebElement getTechnologiesused() {
		return technologiesused;
	}
	public void setTechnologiesused(String technologiesused) {
		this.technologiesused.sendKeys(technologiesused);
	}
	public WebElement getOthertechnologies() {
		return othertechnologies;
	}
	public void setOthertechnologies(String othertechnologies) {
		this.othertechnologies.sendKeys(othertechnologies);
	}
	
public employeedetailspage() {
		super();
	}

public String titlename() {
	return webDriver.getTitle();
	
}
public String textnamee() {
	 return this.textnamee.getText();
	}

public void register() {
	this.registerbtn.click();
}
}